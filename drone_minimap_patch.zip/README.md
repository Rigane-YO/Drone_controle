# Correctif : mini-map sur les coordonnées originales de la carte

Ce patch modifie la méthode `_draw_minimap()` du mini-map déjà installé dans `src/visualizer_3d.py`.

- Les zones et les connexions utilisent `Zone.x` et `Zone.y` provenant directement du fichier de carte (`.txt`).
- Le mini-map ne réutilise plus `self.node_positions`, qui correspond à l'organisation 3D en anneaux.
- L'échelle est uniforme pour préserver les proportions de la carte source.
- Les marqueurs de drones sont interpolés en 2D sur les coordonnées de la carte.
- Une sauvegarde `src/visualizer_3d.py.before-minimap-map-layout.bak` est conservée avant modification.

## Installation

Depuis la racine du projet `Drone_controle`, après avoir installé le premier patch mini-map :

```bash
unzip -n minimap_map_coordinates_patch.zip
python scripts/apply_minimap_map_coordinates_patch.py
python -m py_compile src/visualizer_3d.py
```

Le script s'arrête sans écrire si la méthode de mini-map attendue n'est pas présente. Il ne fait aucun commit ni push.

# Drone_controle — modes de disposition 3D

Le patch ajoute deux modes à `src/visualizer_3d.py` :

- **3D personnalisée** : disposition actuelle par anneaux et niveaux de hauteur.
- **Coordonnées carte** : chaque zone utilise les coordonnées `x` et `y` du fichier `.txt`, remappées sur les axes X et Z de la scène 3D avec une échelle uniforme. La topologie et les proportions du dessin 2D sont donc conservées.

Les deux modes sont disponibles pour toutes les cartes (`easy`, `medium`, `hard`, `challenger` et `other`).

## Installation

À la racine du projet `Drone_controle`, décompressez ce ZIP puis lancez :

```bash
unzip -n drone_layout_modes_patch.zip
python scripts/apply_layout_modes_patch.py
python -m py_compile src/visualizer_3d.py
```

Le script sauvegarde `src/visualizer_3d.py` dans `src/visualizer_3d.py.before-layout-modes.bak` avant sa première modification. Il vérifie les points d'ancrage et la syntaxe avant d'écrire le fichier. Si la version locale diffère trop, il s'arrête sans écraser le fichier.

## Utilisation

- Appuyez sur **V** pendant la simulation pour changer de disposition.
- Ou ouvrez **P → Options** et utilisez le bouton **DISPOSITION**.
- La caméra se recadre et les drones se replacent dans le nouveau layout en conservant leur position logique dans la simulation.
- Le mini-map reste indépendant et continue d'utiliser les coordonnées originales du fichier de carte.

Aucun commit ni push Git n'est effectué.
